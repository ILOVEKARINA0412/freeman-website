Freeman Cheung - Desktop and Mobile Website
Saved release: 20 November 2026 (Hong Kong)

HOW TO OPEN
1. Extract the whole ZIP archive.
2. Open desktop/index.html for the desktop version.
3. Open mobile/index.html for the mobile version.
Keep desktop, mobile and assets together so images and fonts load correctly.

CONTENTS
Each version has separate index.html, styles.css and script.js files.
Shared photos, the embedded Outfit font and About carousel files are in assets/.
The source HTML, CSS, JavaScript and assets are preserved from the current edited website.

This release contains the website only. Video previews and video production files are not included.
No server, package installation or build step is needed to open the HTML files.
The Instagram link opens an external website and needs an internet connection.

MY JOURNEY CARD STACK
Select a chapter, use Previous/Next, swipe horizontally, or focus the cards and use arrow keys, Home or End.
The stack respects reduced-motion settings and does not advance automatically.
Without JavaScript, all three chapters remain readable.
